create view patron_simple as
  select `schema1`.`patron`.`name` AS `name`, `schema1`.`patron`.`email` AS `email`
  from `schema1`.`patron`;

